<?php

define('DB_HOST', '51.158.59.186:14301');
define('DB_NAME', 'DB-DK');
define('DB_USER', 'phppex');
define('DB_PASSWORD', 'Supermotdepasse!42');

?>
