<?php

require_once 'models/TodolistModel.php';

class TodolistController {
    private $model;

    public function __construct() {
        $this->model = new TodolistModel();
    }

    public function index() {
        $todos = $this->model->getAll();
        require 'views/todolist.php';
    }

    public function show($id) {
        $todo = $this->model->getById($id);
        require 'views/Details.php';
    }

    public function create() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $title = $_POST['title'];
            $description = $_POST['description'];
            $this->model->createTodo($title, $description);
            header('Location: index.php');
        } else {
            require 'views/Create.php';
        }
    }

    public function update($id, $title, $description) {
        $this->model->updateTodo($id, $title, $description);
        header('Location: index.php');
    }
}
