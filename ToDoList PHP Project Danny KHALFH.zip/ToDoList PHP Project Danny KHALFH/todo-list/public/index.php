<?php

require_once 'router.php';
require_once 'src/controllers/TodolistController.php';

$action = isset($_GET['action']) ? $_GET['action'] : 'index';

$controller = new TodolistController();

switch ($action) {
    case 'show':
        $id = isset($_GET['id']) ? $_GET['id'] : null;
        $controller->show($id);
        break;
    case 'create':
        $controller->create();
        break;
    default:
        $controller->index();
        break;
}
